export const Header = ({ name }) => <h1 className="App-header">{name}</h1>;
